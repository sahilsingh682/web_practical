<?php 
    include("header.php");
?>
<h2>Employee Manage</h2>
<form method="POST" action="" enctype="multipart/form-data">
<input type="text" name="name">
<input type="email" name="email">
<input type="password" name="password">
<input type="submit">
</form>
<?php 
    include("footer.php");
?>